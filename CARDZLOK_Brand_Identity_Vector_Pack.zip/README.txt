CARDZLOK - brand identity vector pack
Freelancer contest #2801589

vectors/   SVG, AI, EPS and PDF for every lock-up. The .ai files are PDF-compatible Illustrator files (PDF 1.5).
           Every shape is a closed outlined path. There is no live text and no font is needed.
           EPS and PDF are CMYK. Files with light artwork carry a background object named "background";
           delete it to place the logo on your own colour.
png/       Transparent PNG, 3000 px on the long side.

File names
  CARDZLOK_A_...   Concept A - Archival Corner-Lock (recommended)
  CARDZLOK_B_...   Concept B - Isometric Vault-Sleeve
  Horizontal / Stacked / Icon / Wordmark
  FullColor_Light  for white and light surfaces
  FullColor_Dark   for Obsidian Vault Black and dark surfaces
  1C_Black         one colour, 100 % black: deboss, emboss, laser engraving, single-colour print
  1C_White         one colour, white reversed
  Descriptor_...   lock-ups with the optional line COLLECTOR GRADE PROTECTION / TCG ARCHIVAL SYSTEMS

Colour
  Obsidian Vault Black      #0D1117   R13 G17 B23      C78 M68 Y58 K82   PMS Black 6 C
  Graded Gold               #C89D54   R200 G157 B84    C22 M38 Y74 K4    PMS 7555 C
  Archival Titanium Silver  #E2E8F0   R226 G232 B240   C10 M5 Y3 K0      PMS Cool Gray 1 C
  Tournament Cobalt         #2563EB   R37 G99 B235     C85 M60 Y0 K0     PMS 2728 C
  Black #000000 (K100) and white #FFFFFF for one-colour production.
  Pantone numbers are the closest coated references; check them against a printed swatch book before production.

Construction
  Symbol A sits on a 63 x 88 unit grid (trading card ratio). Strokes 12 u, gaps 6 u, corner chamfer 12 u at 45 degrees.
  The wordmark is drawn, not typed. The optional descriptor line is Space Grotesk Medium (SIL Open Font License 1.1), outlined.
  Clear space on every side = half the symbol height. Minimum symbol height 8 mm (foil, deboss), 5 mm (print), 16 px (screen).
